export const getComments = async () => {
  return [
    {
      id: "1",
      body: "First comment",
      username: "Ram",
      userId: "1",
      parentId: null,
      createdAt: "",
    },
    {
      id: "2",
      body: "First comment first child",
      username: "Laskhman",
      userId: "2",
      parentId: "1",
      createdAt: "",
    },
  ];
};

export const createComment = async (text, parentId = null) => {
  return {
    id: Math.random().toString(36).substr(2, 9),
    body: text,
    parentId,
    userId: "1",
    username: "John",
    createdAt: new Date().toISOString(),
  };
};

export const updateComment = async (text) => {
  return { text };
};

export const deleteComment = async () => {
  return {};
};
